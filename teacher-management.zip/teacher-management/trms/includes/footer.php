<footer class="footer-area section_gap">
    <div class="container" align="center">

        <h2 align="center" style="color:#fff"> Teacher Records Management System</h2>
    </div>
</footer>